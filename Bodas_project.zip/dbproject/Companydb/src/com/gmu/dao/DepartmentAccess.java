package com.gmu.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.gmu.model.DepartmentStructure;

public class DepartmentAccess {
	static DBConnection d = null;
	static Connection con = null;
			
	public DepartmentAccess() {
		d = new DBConnection();
		con = d.mainDBConn();
	}
	
	public List<DepartmentStructure> list() throws SQLException {
		
		
		List<DepartmentStructure> listDepartment = new ArrayList<>();
		
		try {
	    	System.out.println("Getting departments..");
	    	String sql = "SELECT * from DEPARTMENT";
	    	PreparedStatement statement = con.prepareStatement(sql);

	        ResultSet result = statement.executeQuery(sql);
	        
	        while (result.next()) {
                int id = result.getInt("dnumber");
                String name = result.getString("dname");
                DepartmentStructure department = new DepartmentStructure(id, name);
                     
                listDepartment.add(department);
            }
	        result.close();
	        statement.close();
	    }catch(Exception e){
	       e.printStackTrace();
	    } finally {
	    	con.close();
	    	if (con.isClosed())
	            System.out.println("Connection auto-suspended");
	        else
	            System.out.println("Connection exists");
	    }
		return listDepartment;
	}
}
