package com.gmu.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.gmu.model.ManagerStructure;

public class ManagerAccess {
	static DBConnection d = null;
	static Connection con = null;
	
	
	public ManagerAccess() {
		d = new DBConnection();
		con = d.mainDBConn();
	}
	
	public List<ManagerStructure> list() throws SQLException {
		List<ManagerStructure> listManager = new ArrayList<>();
		
		try {
	    	System.out.println("Getting Managers..");
	    	String sql = "SELECT mgrssn, fname, lname from employee, department where employee.ssn = department.mgrssn";
	    	PreparedStatement statement = con.prepareStatement(sql);

	        ResultSet result = statement.executeQuery(sql);
	        
	        while (result.next()) {
                int ssn = result.getInt("mgrssn");
                String fname = result.getString("fname");
                String lname = result.getString("lname");
                ManagerStructure manager = new ManagerStructure(ssn, fname, lname);
                     
                listManager.add(manager);
            }
	        result.close();
	        statement.close();
	    } catch(Exception e){
	       e.printStackTrace();
	    } finally {
	    	con.close();
	    	if (con.isClosed())
	            System.out.println("Connection auto-suspended");
	        else
	            System.out.println("Connection exists");
	    }
		return listManager;
	}

}
